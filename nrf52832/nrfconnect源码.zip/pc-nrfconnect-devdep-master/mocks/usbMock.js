// Allows jest to test files that import usb.

module.exports = {};
