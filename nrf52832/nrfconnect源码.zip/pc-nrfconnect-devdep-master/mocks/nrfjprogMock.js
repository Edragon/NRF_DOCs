// Allows jest to test files that import pc-nrfjprog-js.

module.exports = {};
