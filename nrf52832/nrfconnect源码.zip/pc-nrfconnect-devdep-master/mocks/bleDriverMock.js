// Allows jest to test files that import pc-ble-driver-js.

module.exports = {
    AdapterFactory: { getInstance: () => {} },
};
