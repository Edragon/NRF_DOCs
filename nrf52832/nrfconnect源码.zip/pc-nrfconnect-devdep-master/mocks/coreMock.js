// Allows jest to test files that import nrfconnect/core.

module.exports = {
    logger: {},
    getAppDir: () => {},
};
