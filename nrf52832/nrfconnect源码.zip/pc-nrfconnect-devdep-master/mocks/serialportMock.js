// Allows jest to test files that import serialport.

module.exports = {};
