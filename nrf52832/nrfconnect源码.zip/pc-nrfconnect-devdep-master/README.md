# pc-nrfconnect-devdep

This project provides common package dependencies for pc-nrfconnect-* packages.
